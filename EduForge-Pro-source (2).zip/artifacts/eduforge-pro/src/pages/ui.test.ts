// @vitest-environment jsdom
import { createElement } from 'react';
import { fireEvent, render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';
import App from '../App';
import { useEduStore } from '../lib/store';

function renderAt(path: string) {
  window.history.replaceState({}, '', path);
  return render(createElement(App));
}

describe('important learner and author interactions', () => {
  it('validates and creates a module in the module library', () => {
    renderAt('/modules');
    fireEvent.click(screen.getByTestId('button-add-module'));
    fireEvent.click(screen.getByTestId('button-save-module'));
    expect(screen.getByRole('alert')).toHaveTextContent('at least 3 characters');

    fireEvent.change(screen.getByTestId('input-module-title'), { target: { value: 'First apartment basics' } });
    fireEvent.change(screen.getByTestId('input-module-description'), { target: { value: 'A practical guide for planning the first move.' } });
    fireEvent.click(screen.getByTestId('button-save-module'));
    expect(screen.getByText('First apartment basics')).toBeInTheDocument();
    expect(useEduStore.getState().modules.some((module) => module.title === 'First apartment basics')).toBe(true);
  });

  it('gives immediate quiz feedback, records a score, and allows retry', () => {
    renderAt('/lessons');
    fireEvent.click(screen.getByTestId('button-answer-saving-1'));
    expect(screen.getByRole('status')).toHaveTextContent('A repeatable amount builds the habit');
    fireEvent.click(screen.getByTestId('button-complete-lesson'));
    expect(screen.getByText(/Completed · 100% score · 1 attempt/)).toBeInTheDocument();

    fireEvent.click(screen.getByTestId('button-retry-lesson'));
    fireEvent.click(screen.getByTestId('button-answer-saving-0'));
    fireEvent.click(screen.getByTestId('button-complete-lesson'));
    expect(screen.getByText(/Completed · 0% score · 2 attempts/)).toBeInTheDocument();
  });

  it('adds a content block and uses the builder undo and redo controls', () => {
    renderAt('/builder/m-saving');
    const initialCount = useEduStore.getState().modules.find((module) => module.id === 'm-saving')?.blocks.length ?? 0;
    fireEvent.change(screen.getByTestId('select-block-type'), { target: { value: 'paragraph' } });
    fireEvent.click(screen.getByTestId('button-add-block'));
    expect(useEduStore.getState().modules.find((module) => module.id === 'm-saving')?.blocks).toHaveLength(initialCount + 1);

    fireEvent.click(screen.getByTestId('button-undo'));
    expect(useEduStore.getState().modules.find((module) => module.id === 'm-saving')?.blocks).toHaveLength(initialCount);
    fireEvent.click(screen.getByTestId('button-redo'));
    expect(useEduStore.getState().modules.find((module) => module.id === 'm-saving')?.blocks).toHaveLength(initialCount + 1);
  });

  it('validates calculator inputs and shows lesson progress and an earned badge', () => {
    const calculator = renderAt('/calculators');
    fireEvent.click(screen.getByTestId('button-calculator-sip'));
    fireEvent.change(screen.getByTestId('input-monthly'), { target: { value: '0' } });
    expect(screen.getByRole('alert')).toHaveTextContent('Enter amounts within the shown ranges');
    calculator.unmount();

    useEduStore.getState().completeLesson('saving', 100);
    renderAt('/progress');
    expect(screen.getByText('1 / 5')).toBeInTheDocument();
    expect(screen.getByTestId('badge-first')).toHaveTextContent('Earned');
  });
});
