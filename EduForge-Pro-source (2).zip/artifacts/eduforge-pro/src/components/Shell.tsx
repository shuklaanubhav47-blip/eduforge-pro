import { useEffect, useState, type ReactNode } from 'react';
import { motion } from 'framer-motion';
import { Link, useLocation } from 'wouter';
import { BarChart3, BookOpen, Calculator, CircleHelp, Coins, LayoutDashboard, Library, Plus } from 'lucide-react';

const nav=[{href:'/',label:'Overview',icon:LayoutDashboard},{href:'/modules',label:'Module library',icon:Library},{href:'/lessons',label:'Learning paths',icon:BookOpen},{href:'/calculators',label:'Money tools',icon:Calculator},{href:'/progress',label:'Learner progress',icon:BarChart3}];
export function Shell({children}:{children:ReactNode}){
 const [path]=useLocation();return <div className="app-shell">
  <aside className="sidebar"><Link href="/" className="brand" data-testid="link-brand-home"><span className="brand-mark"><Coins size={18}/></span><span>EduForge <span style={{color:'#dfa455'}}>Pro</span></span></Link>
   <div className="nav-label">Workspace</div>{nav.map(({href,label,icon:Icon})=><Link key={href} href={href} className={`nav-link ${path===href?'active':''}`} data-testid={`link-nav-${label.toLowerCase().replaceAll(' ','-')}`}><Icon size={17}/>{label}</Link>)}
   <div className="nav-label" style={{marginTop:'auto'}}>Teaching toolkit</div><div style={{padding:'11px 12px',fontSize:12,lineHeight:1.55,color:'#aeb7b4'}}>Turn practical money ideas into learning that sticks.</div>
   <Link href="/builder/new" className="btn btn-primary" style={{margin:'8px 6px'}} data-testid="button-create-module"><Plus size={15}/>New module</Link>
   <div style={{borderTop:'1px solid #3d4851',marginTop:18,padding:'18px 11px 0',fontSize:11,color:'#aeb7b4',display:'flex',alignItems:'center',gap:9}}><span className="brand-mark" style={{width:28,height:28,borderRadius:50,fontSize:11}}>EF</span> Local workspace <span style={{marginLeft:'auto',width:7,height:7,background:'#83bc9c',borderRadius:9}} /></div>
  </aside>
  <main className="main-area"><header className="topbar"><div style={{fontSize:12,color:'hsl(var(--muted-foreground))'}}>Financial literacy workspace <span style={{padding:'0 7px'}}> / </span><span style={{color:'hsl(var(--foreground))',fontWeight:700}}>{nav.find(n=>n.href===path)?.label||'Module studio'}</span></div><div style={{display:'flex',gap:10,alignItems:'center'}}><span className="pill pill-green">Saved on this device</span><button className="btn btn-quiet" aria-label="About EduForge" onClick={()=>window.dispatchEvent(new CustomEvent('edu-toast',{detail:'Your content and learner progress stay in this browser.'}))} data-testid="button-about"><CircleHelp size={17}/></button></div></header><motion.div key={path} initial={{opacity:0,y:5}} animate={{opacity:1,y:0}} transition={{duration:.2}}>{children}</motion.div></main>
  <nav className="mobile-nav">{nav.map(({href,label,icon:Icon})=><Link href={href} key={href} aria-label={label} data-testid={`mobile-nav-${label.toLowerCase().replaceAll(' ','-')}`}><Icon size={18}/><span>{label.split(' ')[0]}</span></Link>)}</nav>
 </div>
}
export function ToastHost(){const [message,setMessage]=useState('');useEffect(()=>{const listener=(e:Event)=>{setMessage((e as CustomEvent<string>).detail);window.setTimeout(()=>setMessage(''),2600)};window.addEventListener('edu-toast',listener);return()=>window.removeEventListener('edu-toast',listener)},[]);return message?<div className="toast" role="status" data-testid="status-toast">{message}</div>:null}
export const toast=(message:string)=>window.dispatchEvent(new CustomEvent('edu-toast',{detail:message}));
