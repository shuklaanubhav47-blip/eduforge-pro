import { type ReactNode } from 'react';
import { Link, Route, Switch, useLocation, Router as WouterRouter } from 'wouter';
import { ErrorBoundary } from '@/components/error-boundary';
import { Shell, ToastHost } from '@/components/Shell';
import Dashboard from '@/pages/Dashboard';
import Modules from '@/pages/Modules';
import Builder from '@/pages/Builder';
import Lessons from '@/pages/Lessons';
import Calculators from '@/pages/Calculators';
import Progress from '@/pages/Progress';

function NotFound(){return <div className="content"><div className="surface" style={{padding:36,textAlign:'center',maxWidth:560,margin:'10vh auto'}}><div className="eyebrow">Nothing on this page</div><h1 className="font-display" style={{fontSize:30}}>We couldn't find that workspace.</h1><p style={{color:'hsl(var(--muted-foreground))'}}>The page may have moved, or the link may be incomplete.</p><Link href="/" className="btn btn-primary" data-testid="link-not-found-home">Back to overview</Link></div></div>}
function Router(){
 const [location]=useLocation();
 return <ErrorBoundary resetKey={location}><Shell><Switch>
  <Route path="/" component={Dashboard}/>
  <Route path="/modules" component={Modules}/>
  <Route path="/builder/:id" component={Builder}/>
  <Route path="/lessons" component={Lessons}/>
  <Route path="/calculators" component={Calculators}/>
  <Route path="/progress" component={Progress}/>
  <Route component={NotFound}/>
 </Switch></Shell></ErrorBoundary>
}
function App(){return <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/,'')}><Router/><ToastHost/></WouterRouter>}
export default App;
