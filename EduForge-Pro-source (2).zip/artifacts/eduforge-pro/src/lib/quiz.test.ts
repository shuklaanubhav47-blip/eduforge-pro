import { describe, expect, it } from 'vitest';
import { scoreQuiz } from './quiz';

describe('quiz scoring', () => {
  it('returns no score before an answer is selected', () => {
    expect(scoreQuiz(null, 1)).toBeNull();
  });

  it('scores correct and incorrect answers consistently', () => {
    expect(scoreQuiz(1, 1)).toBe(100);
    expect(scoreQuiz(0, 1)).toBe(0);
  });
});
