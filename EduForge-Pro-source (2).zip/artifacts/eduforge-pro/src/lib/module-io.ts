import { ModuleSchema, type EduModule } from './model';

export function exportModuleJson(module: EduModule): string {
  return JSON.stringify(module, null, 2);
}

export function parseModuleJson(
  raw: string,
  id = crypto.randomUUID(),
  updatedAt = new Date().toISOString(),
): EduModule {
  let parsed: unknown;
  try {
    parsed = JSON.parse(raw);
  } catch {
    throw new Error('That file is not valid JSON.');
  }

  if (typeof parsed !== 'object' || parsed === null || Array.isArray(parsed)) {
    throw new Error('The JSON file must contain one module object.');
  }

  const result = ModuleSchema.safeParse({ ...parsed, id, updatedAt });
  if (!result.success) {
    throw new Error(result.error.issues.map((issue) => issue.message).join(' '));
  }
  return result.data;
}
