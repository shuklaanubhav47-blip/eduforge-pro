export function scoreQuiz(answer: number | null, correctAnswer: number): number | null {
  if (answer === null) return null;
  return answer === correctAnswer ? 100 : 0;
}
