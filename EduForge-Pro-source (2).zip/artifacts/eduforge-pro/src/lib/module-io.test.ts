import { describe, expect, it } from 'vitest';
import { defaultModules } from './model';
import { exportModuleJson, parseModuleJson } from './module-io';

describe('module JSON import and export', () => {
  it('round-trips the complete module data shape', () => {
    const source = defaultModules[0];
    expect(JSON.parse(exportModuleJson(source))).toEqual(source);
    expect(parseModuleJson(exportModuleJson(source), 'imported-module', '2026-10-18T00:00:00.000Z')).toMatchObject({
      ...source,
      id: 'imported-module',
      updatedAt: '2026-10-18T00:00:00.000Z',
    });
  });

  it('rejects malformed JSON with a direct message', () => {
    expect(() => parseModuleJson('{not json')).toThrow('That file is not valid JSON.');
  });

  it('rejects non-object JSON values', () => {
    expect(() => parseModuleJson('[]')).toThrow('one module object');
  });

  it('validates imported content and reports schema issues', () => {
    const invalid = { ...defaultModules[0], title: '' };
    expect(() => parseModuleJson(JSON.stringify(invalid))).toThrow('at least 3 characters');
  });
});
