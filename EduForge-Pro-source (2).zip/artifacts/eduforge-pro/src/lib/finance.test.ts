import { describe, expect, it } from 'vitest';
import { compound, emi, isValidRange, money, sip } from './finance';

describe('financial learning calculations',()=>{
 it('calculates monthly payment for a zero-interest loan',()=>expect(emi(1200,0,12)).toBe(100));
  it('calculates a fixed-rate amortized payment',()=>expect(emi(1200,12,12)).toBeCloseTo(106.62,2));
  it('projects regular contributions with zero interest',()=>expect(sip(100,0,2)).toBe(2400));
  it('calculates a monthly-contribution SIP with compounding',()=>expect(sip(100,12,1)).toBeCloseTo(1268.25,2));
 it('calculates compound value and contributions',()=>expect(compound(1000,0,2,50)).toBe(2200));
  it('calculates compound growth at a nonzero rate',()=>expect(compound(1000,12,1)).toBeCloseTo(1126.83,2));
  it('returns zero for invalid or non-finite formula inputs',()=>{
    expect(emi(1000,5,0)).toBe(0);
    expect(emi(Number.NaN,5,12)).toBe(0);
    expect(sip(100,-1,1)).toBe(0);
    expect(compound(1000,5,1,-1)).toBe(0);
  });
  it('validates calculator entry ranges including non-finite values',()=>{
    expect(isValidRange(0,0,50)).toBe(true);
    expect(isValidRange(51,0,50)).toBe(false);
    expect(isValidRange(Number.NaN,0,50)).toBe(false);
    expect(isValidRange(Number.POSITIVE_INFINITY,0,50)).toBe(false);
  });
  it('formats values safely for the interface',()=>{
    expect(money(1234)).toBe('$1,234');
    expect(money(Number.NaN)).toBe('$0');
  });
});
