import { z } from 'zod';

export const BlockType = z.enum(['heading','paragraph','richText','image','video','bulletList','numberedList','definition','callout','quiz','calculator','explainer','divider']);
export type BlockType = z.infer<typeof BlockType>;
export type QuizOption = { text: string };
export type ModuleBlock = { id:string; type:BlockType; title?:string; content?:string; items?:string[]; options?:QuizOption[]; correctAnswer?:number; explanation?:string };
export type EduModule = {
  id:string; title:string; description:string; category:string; level:string; updatedAt:string;
  settings:{minutes:number;visibility:'Draft'|'Published'}; blocks:ModuleBlock[];
};
export const ModuleSchema = z.object({
  id:z.string().min(1), title:z.string().min(3,'Title must be at least 3 characters').max(90),
  description:z.string().min(8,'Add a little more detail to the description').max(400),
  category:z.string().min(1), level:z.enum(['Beginner','Intermediate','Advanced']),
  updatedAt:z.string(), settings:z.object({minutes:z.number().int().min(1).max(300),visibility:z.enum(['Draft','Published'])}),
  blocks:z.array(z.object({id:z.string().min(1),type:BlockType,title:z.string().optional(),content:z.string().optional(),items:z.array(z.string()).optional(),options:z.array(z.object({text:z.string()})).optional(),correctAnswer:z.number().int().nonnegative().optional(),explanation:z.string().optional()}))
}).superRefine((module,ctx)=>{
 const ids=new Set<string>();
 module.blocks.forEach((block,index)=>{
  if(ids.has(block.id))ctx.addIssue({code:'custom',path:['blocks',index,'id'],message:'Every block needs a unique id.'});
  ids.add(block.id);
  if(block.type==='quiz'&&(!block.options||block.options.length<2||block.options.some(o=>!o.text.trim())))ctx.addIssue({code:'custom',path:['blocks',index,'options'],message:'A quiz needs at least two completed answer options.'});
  if(block.type==='quiz'&&block.options&&block.correctAnswer===undefined)ctx.addIssue({code:'custom',path:['blocks',index,'correctAnswer'],message:'Select a correct answer for every quiz.'});
  if(block.type==='quiz'&&block.options&&block.correctAnswer!==undefined&&block.correctAnswer>=block.options.length)ctx.addIssue({code:'custom',path:['blocks',index,'correctAnswer'],message:'Select a correct answer within the available options.'});
 });
});
export const defaultModules:EduModule[]=[
 {id:'m-saving',title:'Build your first safety net',description:'A practical, no-shame guide to making an emergency fund that fits real life.',category:'Saving',level:'Beginner',updatedAt:new Date().toISOString(),settings:{minutes:12,visibility:'Published'},blocks:[
  {id:'b1',type:'heading',content:'Start with a little breathing room'}, {id:'b2',type:'paragraph',content:'An emergency fund is money set aside for the surprises life brings. It is not about having a perfect number; it is about building options, one small deposit at a time.'},
  {id:'b3',type:'definition',title:'Emergency fund',content:'Cash kept accessible for unexpected costs such as a repair, medical bill, or a gap in income.'},
  {id:'b4',type:'explainer',title:'Small deposits add up',content:'Saving $18 each week adds $936 over a year, before interest. Start with a target that feels possible, then revisit it as your situation changes.'},
  {id:'b5',type:'quiz',title:'Quick check',content:'Which expense is a good reason to use an emergency fund?',options:[{text:'A planned concert ticket'},{text:'An unexpected car repair'},{text:'A weekly grocery shop'}],correctAnswer:1,explanation:'A surprise repair is exactly the kind of unplanned expense this fund can help absorb.'}]},
 {id:'m-budget',title:'A budget that bends',description:'Build a flexible spending plan around what matters, not a rigid set of rules.',category:'Budgeting',level:'Beginner',updatedAt:new Date().toISOString(),settings:{minutes:15,visibility:'Published'},blocks:[{id:'b6',type:'heading',content:'Give every dollar a direction'},{id:'b7',type:'paragraph',content:'A useful budget is a snapshot, not a judgement. Start with take-home income, name fixed costs, and leave room for the things that make life feel like yours.'}]},
 {id:'m-growth',title:'The quiet force of compounding',description:'See how time, rate, and regular contributions can change the shape of a goal.',category:'Investing',level:'Intermediate',updatedAt:new Date().toISOString(),settings:{minutes:18,visibility:'Draft'},blocks:[{id:'b8',type:'heading',content:'Time does some of the work'},{id:'b9',type:'paragraph',content:'Compound growth means returns can earn returns. It is a mathematical effect, not a guarantee of investment performance.'}]}
];
