import { describe, expect, it } from 'vitest';
import { BlockType, defaultModules, ModuleSchema } from './model';

describe('module schema', () => {
  it('accepts the fictional starter modules', () => {
    for (const module of defaultModules) {
      expect(ModuleSchema.safeParse(module).success).toBe(true);
    }
  });

  it('supports every requested content block type', () => {
    expect(BlockType.options).toEqual([
      'heading', 'paragraph', 'richText', 'image', 'video', 'bulletList',
      'numberedList', 'definition', 'callout', 'quiz', 'calculator',
      'explainer', 'divider',
    ]);
  });

  it('rejects duplicate block ids', () => {
    const module = structuredClone(defaultModules[0]);
    module.blocks.push({ ...module.blocks[0] });
    const result = ModuleSchema.safeParse(module);
    expect(result.success).toBe(false);
    if (!result.success) {
      expect(result.error.issues.map((issue) => issue.message)).toContain('Every block needs a unique id.');
    }
  });

  it('requires complete quiz options and a valid correct answer', () => {
    const module = structuredClone(defaultModules[0]);
    const quiz = module.blocks.find((block) => block.type === 'quiz');
    expect(quiz).toBeDefined();
    if (!quiz) return;

    quiz.correctAnswer = undefined;
    expect(ModuleSchema.safeParse(module).success).toBe(false);
    quiz.correctAnswer = 8;
    expect(ModuleSchema.safeParse(module).success).toBe(false);
    quiz.correctAnswer = 1;
    quiz.options = [{ text: 'Complete option' }, { text: ' ' }];
    expect(ModuleSchema.safeParse(module).success).toBe(false);
  });

  it('reports helpful errors for an invalid module title', () => {
    const module = structuredClone(defaultModules[0]);
    module.title = 'No';
    const result = ModuleSchema.safeParse(module);
    expect(result.success).toBe(false);
    if (!result.success) {
      expect(result.error.issues.some((issue) => issue.message.includes('at least 3 characters'))).toBe(true);
    }
  });
});
