export function isValidRange(value: number, min: number, max: number): boolean {
  return Number.isFinite(value) && value >= min && value <= max;
}

export function emi(principal:number,annualRate:number,months:number){
  if(!Number.isFinite(principal)||!Number.isFinite(annualRate)||!Number.isFinite(months)||principal<=0||months<=0||annualRate<0)return 0;
  const r=annualRate/1200;
  if(r===0)return principal/months;
  return principal*r*Math.pow(1+r,months)/(Math.pow(1+r,months)-1);
}

export function sip(monthly:number,annualRate:number,years:number){
  if(!Number.isFinite(monthly)||!Number.isFinite(annualRate)||!Number.isFinite(years)||monthly<=0||years<=0||annualRate<0)return 0;
  const n=Math.round(years*12),r=annualRate/1200;
  if(r===0)return monthly*n;
  return monthly*((Math.pow(1+r,n)-1)/r);
}

export function compound(principal:number,annualRate:number,years:number,monthlyContribution=0){
  if(!Number.isFinite(principal)||!Number.isFinite(annualRate)||!Number.isFinite(years)||!Number.isFinite(monthlyContribution)||principal<0||years<=0||annualRate<0||monthlyContribution<0)return 0;
  const n=years*12,r=annualRate/1200;
  if(r===0)return principal+monthlyContribution*n;
  return principal*Math.pow(1+r,n)+monthlyContribution*((Math.pow(1+r,n)-1)/r);
}

export function money(value:number){return new Intl.NumberFormat('en-US',{style:'currency',currency:'USD',maximumFractionDigits:0}).format(Number.isFinite(value)?value:0)}
