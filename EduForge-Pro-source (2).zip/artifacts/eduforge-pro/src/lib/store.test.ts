// @vitest-environment jsdom
import { beforeEach, describe, expect, it } from 'vitest';
import { defaultModules } from './model';
import { useEduStore } from './store';

function resetStore() {
  localStorage.clear();
  useEduStore.setState({
    modules: structuredClone(defaultModules),
    progress: {},
    past: [],
    future: [],
  });
}

describe('EduForge local state', () => {
  beforeEach(resetStore);

  it('creates, edits, undoes, and redoes a module', () => {
    const store = useEduStore.getState();
    const module = { ...structuredClone(defaultModules[0]), id: 'created', title: 'A new lesson' };
    store.addModule(module);
    expect(useEduStore.getState().modules[0].id).toBe('created');

    useEduStore.getState().updateModule({ ...module, title: 'Revised lesson' });
    expect(useEduStore.getState().modules[0].title).toBe('Revised lesson');
    useEduStore.getState().undo();
    expect(useEduStore.getState().modules[0].title).toBe('A new lesson');
    useEduStore.getState().redo();
    expect(useEduStore.getState().modules[0].title).toBe('Revised lesson');
  });

  it('duplicates with fresh module and block ids, then deletes', () => {
    const original = useEduStore.getState().modules[0];
    useEduStore.getState().duplicateModule(original.id);
    const duplicate = useEduStore.getState().modules[0];

    expect(duplicate.id).not.toBe(original.id);
    expect(duplicate.title).toBe(`${original.title} copy`);
    expect(duplicate.settings.visibility).toBe('Draft');
    expect(duplicate.blocks.map((block) => block.id)).not.toEqual(original.blocks.map((block) => block.id));

    useEduStore.getState().deleteModule(duplicate.id);
    expect(useEduStore.getState().modules.some((module) => module.id === duplicate.id)).toBe(false);
  });

  it('reorders content blocks and records a reversible state', () => {
    const module = useEduStore.getState().modules[0];
    const reversed = [...module.blocks].reverse();
    useEduStore.getState().reorderBlocks(module.id, reversed);
    expect(useEduStore.getState().modules[0].blocks.map((block) => block.id)).toEqual(reversed.map((block) => block.id));
    useEduStore.getState().undo();
    expect(useEduStore.getState().modules[0].blocks.map((block) => block.id)).toEqual(module.blocks.map((block) => block.id));
  });

  it('tracks lesson completion, latest score, and retry count', () => {
    useEduStore.getState().completeLesson('saving', 0);
    useEduStore.getState().completeLesson('saving', 100);
    expect(useEduStore.getState().progress.saving).toMatchObject({
      completed: true,
      score: 100,
      attempts: 2,
    });
  });

  it('caps undo history at 50 states', () => {
    const original = useEduStore.getState().modules[0];
    for (let index = 0; index < 55; index += 1) {
      useEduStore.getState().updateModule({ ...original, title: `Lesson revision ${index}` });
    }
    expect(useEduStore.getState().past).toHaveLength(50);
  });

  it('does nothing when duplicating a missing module or undoing an empty history', () => {
    const current = useEduStore.getState().modules;
    useEduStore.getState().duplicateModule('missing-module');
    useEduStore.getState().undo();
    useEduStore.getState().redo();
    expect(useEduStore.getState().modules).toEqual(current);
  });

  it('persists created modules in browser storage', () => {
    const module = { ...structuredClone(defaultModules[0]), id: 'stored-module', title: 'Saved locally' };
    useEduStore.getState().addModule(module);
    const saved = JSON.parse(localStorage.getItem('eduforge-pro-v1') || '{}');
    expect(saved.state.modules[0].title).toBe('Saved locally');
  });
});
