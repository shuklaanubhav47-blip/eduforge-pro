import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import { defaultModules, type EduModule, type ModuleBlock } from './model';

type ProgressItem={completed:boolean; score:number; attempts:number; updatedAt:string};
type Store={
 modules:EduModule[];
 progress:Record<string,ProgressItem>;
 past:EduModule[][];
 future:EduModule[][];
 completeLesson:(id:string,score:number)=>void;
 addModule:(module:EduModule)=>void;
 updateModule:(module:EduModule)=>void;
 deleteModule:(id:string)=>void;
 duplicateModule:(id:string)=>void;
 reorderBlocks:(moduleId:string,blocks:ModuleBlock[])=>void;
 undo:()=>void;
 redo:()=>void;
};
const HISTORY_LIMIT=50;
export const useEduStore=create<Store>()(persist((set,get)=>({
 modules:defaultModules,progress:{},past:[],future:[],
 completeLesson:(id,score)=>set(s=>({progress:{...s.progress,[id]:{completed:true,score,attempts:(s.progress[id]?.attempts||0)+1,updatedAt:new Date().toISOString()}}})),
 addModule:module=>set(s=>({modules:[module,...s.modules],past:[...s.past,s.modules].slice(-HISTORY_LIMIT),future:[]})),
 updateModule:module=>set(s=>({modules:s.modules.map(m=>m.id===module.id?module:m),past:[...s.past,s.modules].slice(-HISTORY_LIMIT),future:[]})),
 deleteModule:id=>set(s=>({modules:s.modules.filter(m=>m.id!==id),past:[...s.past,s.modules].slice(-HISTORY_LIMIT),future:[]})),
 duplicateModule:id=>{const original=get().modules.find(m=>m.id===id);if(!original)return; const copy={...original,id:crypto.randomUUID(),title:`${original.title} copy`,settings:{...original.settings,visibility:'Draft' as const},updatedAt:new Date().toISOString(),blocks:original.blocks.map(b=>({...b,id:crypto.randomUUID()}))};set(s=>({modules:[copy,...s.modules],past:[...s.past,s.modules].slice(-HISTORY_LIMIT),future:[]}));},
 reorderBlocks:(moduleId,blocks)=>set(s=>({modules:s.modules.map(m=>m.id===moduleId?{...m,blocks,updatedAt:new Date().toISOString()}:m),past:[...s.past,s.modules].slice(-HISTORY_LIMIT),future:[]})),
 undo:()=>set(s=>{if(!s.past.length)return s;const previous=s.past[s.past.length-1];return {modules:previous,past:s.past.slice(0,-1),future:[s.modules,...s.future].slice(0,HISTORY_LIMIT)}}),
 redo:()=>set(s=>{if(!s.future.length)return s;const [next,...future]=s.future;return {modules:next,past:[...s.past,s.modules].slice(-HISTORY_LIMIT),future}}),
}),{name:'eduforge-pro-v1',storage:createJSONStorage(()=>localStorage)}));
