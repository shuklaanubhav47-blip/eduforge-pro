import { describe, expect, it } from 'vitest';
import { cn } from './utils';

describe('class composition helper', () => {
  it('combines classes and keeps the last conflicting utility', () => {
    expect(cn('p-2 text-sm', 'p-4', false && 'hidden')).toBe('text-sm p-4');
  });
});
