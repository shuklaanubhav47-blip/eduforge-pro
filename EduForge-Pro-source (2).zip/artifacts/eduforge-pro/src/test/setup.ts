import '@testing-library/jest-dom/vitest';
import { cleanup } from '@testing-library/react';
import { afterEach, beforeEach } from 'vitest';
import { defaultModules } from '../lib/model';
import { useEduStore } from '../lib/store';

if (typeof globalThis.ResizeObserver === 'undefined') {
  globalThis.ResizeObserver = class ResizeObserverStub {
    observe() {}
    unobserve() {}
    disconnect() {}
  };
}

beforeEach(() => {
  localStorage.clear();
  useEduStore.setState({
    modules: structuredClone(defaultModules),
    progress: {},
    past: [],
    future: [],
  });
});

afterEach(() => {
  cleanup();
});
