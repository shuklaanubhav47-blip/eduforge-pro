# EduForge Pro

EduForge Pro is a local-first financial literacy workspace for educators. It turns practical money concepts into focused, interactive lessons and provides lightweight learner progress signals without accounts, a server, or third-party data services.

## Features

- Dashboard with a quick view of module inventory, publishing status, lesson activity, and a practical starting point.
- Module library with search, create, edit, duplicate, delete, JSON import, and JSON export.
- Block-based authoring for headings, paragraphs, rich text, images, video, lists, definitions, callouts, quizzes, calculator embeds, explainers, and dividers.
- Keyboard-accessible block reordering with drag handles plus explicit move-up / move-down controls.
- Desktop, tablet, and mobile learner previews that remain scrollable at narrow sizes.
- Five interactive learning paths: saving, budgeting, compound interest, loan repayment, and investing.
- EMI, SIP, and compound-growth estimators with input bounds, explanations, and charts.
- Local completion records, quiz scores, attempts, and milestone badges.
- Zod schema validation for module structures and friendly validation messages on module creation and import.
- Responsive layout, visible focus treatment, accessible control labels, and no-auth local persistence.

All sample content is fictional and educational. Calculations are illustrations, not financial advice or promises of performance.

## Stack

- React, TypeScript, Vite, Tailwind CSS
- Zustand with `persist` / browser `localStorage`
- Wouter routing
- Framer Motion page transitions, dnd-kit sortable authoring controls
- Recharts visualizations, Lucide icons
- Zod validation, Vitest and React Testing Library dependencies

## Install and run

From the workspace root:

```bash
pnpm install
pnpm --filter @workspace/eduforge-pro run dev
```

## Commands

```bash
pnpm --filter @workspace/eduforge-pro run dev
pnpm --filter @workspace/eduforge-pro run build
pnpm --filter @workspace/eduforge-pro run serve
pnpm --filter @workspace/eduforge-pro run typecheck
pnpm --filter @workspace/eduforge-pro run test
pnpm --filter @workspace/eduforge-pro run test:coverage
pnpm --filter @workspace/eduforge-pro run test:watch
```

The Replit workflow provides the preview port and base path. Outside the workflow, Vite defaults to port `5173` at `/`.

## Structure

```text
src/
  components/        Shared app shell and toast feedback
  lib/
    finance.ts       Reusable EMI, SIP, and compound-interest formulas
    finance.test.ts  Financial calculation and input-range tests
    model.ts         Module and block validation schemas
    module-io.ts     Validated JSON import and export
    quiz.ts          Shared answer-scoring rules
    store.ts         Persisted modules, progress, and history
    *.test.ts        Formula, validation, import/export, quiz, and state tests
  pages/             Dashboard, library, builder, learning, tools, progress
  App.tsx            Wouter routes and shared workspace frame
  index.css          Theme tokens, responsive rules, and design system
```

## Usage

Open **Module library** to create or import a module. Open a module in the studio to edit its metadata, add content blocks, reorder them by keyboard or pointer, and switch the learner preview width. Publishing is a local module state. In **Learning paths**, select a topic, complete its short knowledge check, and revisit it to retry. **Money tools** provide interactive what-if estimates, while **Learner progress** summarizes completion and quiz scores.

Modules and learning progress persist in the current browser profile. The module editor keeps up to 50 module history states for undo and redo. Import accepts one JSON module matching the app schema; export downloads a portable JSON file. Clearing browser site data removes local content.

The coverage command measures the full `src/lib` logic layer; the React Testing Library suite separately exercises module creation, content editing, undo/redo, quiz feedback, calculator validation, and progress badges.

## Privacy and limitations

No authentication, server, database, paid API, or credential is used. All workspace data is stored in browser local storage. Learning examples are intentionally educational and not individualized financial guidance.
